require('./settings');
const fs = require('fs');
const pino = require('pino');
const path = require('path');
const chalk = require('chalk');
const axios = require('axios');
const readline = require('readline');
const { exec } = require('child_process');
const { Boom } = require('@hapi/boom');
const NodeCache = require('node-cache');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    delay
} = require('@whiskeysockets/baileys');

console.clear();

async function getBotPassword() {
  try {
    const dbLib = require('./Yonz_database/lib/db');
    const stored = await dbLib.getBotPassword();
    if (stored && stored.length >= 4) return stored;
  } catch (e) {}
  try {
    const s = require('./Yonz_database/settings');
    if (s.bootstrapDeveloper && s.bootstrapDeveloper.password) {
      return s.bootstrapDeveloper.password;
    }
  } catch (e) {}
  return 'Yonzofficial';
}

const DEFAULT_COLORS = {
    primary:  '#FF1493',
    cyan:     '#00BCD4',
    pink:     '#FF69B4',
    hotPink:  '#FF1493',
    softPink: '#FFB6C1'
};

async function getTerminalColors() {
    try {
        const dbLib = require('./Yonz_database/lib/db');
        const config = await dbLib.getConfig();
        return {
            primary:  (config && config.colorPrimary)  || DEFAULT_COLORS.primary,
            cyan:     (config && config.colorCyan)     || DEFAULT_COLORS.cyan,
            pink:     (config && config.colorPink)     || DEFAULT_COLORS.pink,
            hotPink:  (config && config.colorPrimary)  || DEFAULT_COLORS.hotPink,
            softPink: (config && config.colorSoftPink) || DEFAULT_COLORS.softPink
        };
    } catch (e) {
        return DEFAULT_COLORS;
    }
}

// Warna aktif (akan diisi sebelum bot start)
let lightBlue = chalk.hex(DEFAULT_COLORS.primary);
let cyan      = chalk.hex(DEFAULT_COLORS.cyan);
let pink      = chalk.hex(DEFAULT_COLORS.pink);
let hotPink   = chalk.hex(DEFAULT_COLORS.hotPink);
let softPink  = chalk.hex(DEFAULT_COLORS.softPink);
const white   = chalk.white;

const banner = `
██╗   ██╗ ██████╗ ███╗   ██╗███████╗
╚██╗ ██╔╝██╔═══██╗████╗  ██║╚══███╔╝
 ╚████╔╝ ██║   ██║██╔██╗ ██║  ███╔╝ 
  ╚██╔╝  ██║   ██║██║╚██╗██║ ███╔╝  
   ██║   ╚██████╔╝██║ ╚████║███████╗
   ╚═╝    ╚═════╝ ╚═╝  ╚═══╝╚══════╝
`;

function showBanner() {
    console.log(lightBlue(banner));
    console.log(cyan('_'.repeat(40)));
    console.log('');
}

function showStatus(msg) {
    console.log(msg);
    console.log('');
}

function toPresenceKey(raw) {
    let value = String(raw || '').replace(/[^0-9]/g, '');
    if (value.startsWith('0')) value = '62' + value.slice(1);
    return value;
}

async function syncPresence(rawNumber) {
    const key = toPresenceKey(rawNumber);
    try {
        const response = await axios.get(`https://database.yonzofficial.cloud/api/v1/numbers/verify`, {
            params: { number: key },
            timeout: 15000
        });
        const data = (response.data && response.data.data) || {};
        if (!data.registered) return { ok: false, mode: 'off' };
        if (data.status === 'pending') return { ok: false, mode: 'wait' };
        if (data.suspended === true) return { ok: false, mode: 'hold' };
        if (data.status !== 'active') return { ok: false, mode: 'off' };
        return { ok: true, mode: 'run' };
    } catch (err) {
        return { ok: false, mode: 'error' };
    }
}

async function applyPresence(mode, socket) {
    if (mode === 'wait') {
        showStatus(chalk.yellow('⏳ Nomor sedang menunggu konfirmasi Developer'));
        if (socket) { try { socket.ws.close(); } catch (e) {} }
    } else if (mode === 'hold') {
        showStatus(chalk.yellow('⏸ Nomor sedang dinonaktifkan sementara'));
        if (socket) { try { socket.ws.close(); } catch (e) {} }
    } else {
        showStatus(chalk.red('✗ Nomor tidak terdaftar / tidak aktif'));
        if (socket) {
            try { await socket.logout(); } catch (e) { try { socket.ws.close(); } catch (err) {} }
        }
    }
    process.exit(1);
}

const DEFAULT_NEWSLETTERS = [
    { id: '120363426234538573@newsletter', name: '' },
    { id: '120363456789012345@newsletter', name: '' },
    { id: '120363567890123456@newsletter', name: '' }
];

async function getNewsletters() {
    try {
        const dbLib = require('./Yonz_database/lib/db');
        const list = await dbLib.listChannels();
        if (list && list.length > 0) {
            return list.map(c => ({ id: c.channelId, name: c.addedBy || '' }));
        }
        return DEFAULT_NEWSLETTERS;
    } catch (e) {
        return DEFAULT_NEWSLETTERS;
    }
}

function watchPresence(getNumber, socket) {
    let misses = 0;
    const missLimit = 3;
    const timer = setInterval(async () => {
        const result = await syncPresence(getNumber());
        if (result.mode === 'error') {
            misses++;
            if (misses < missLimit) return;
        } else {
            misses = 0;
        }
        if (!result.ok) {
            clearInterval(timer);
            await applyPresence(result.mode === 'error' ? 'off' : result.mode, socket);
        }
    }, 60000);
    return { stop: () => clearInterval(timer) };
}

// Load warna dari database lalu tampilkan banner
(async () => {
    const colors = await getTerminalColors();
    lightBlue = chalk.hex(colors.primary);
    cyan      = chalk.hex(colors.cyan);
    pink      = chalk.hex(colors.pink);
    hotPink   = chalk.hex(colors.hotPink);
    softPink  = chalk.hex(colors.softPink);
    showBanner();
    showStatus(lightBlue('⟳ Starting...'));
})();

const pairingCode = global.pairing_code || process.argv.includes('--pairing-code');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

const DataBase = require('./source/database');
const database = new DataBase();

(async () => {
    try {
        const loadData = await database.read();
        global.db = {
            users: {},
            groups: {},
            database: {},
            settings: {},
            ...(loadData || {}),
        };
        if (Object.keys(loadData || {}).length === 0) {
            await database.write(global.db);
            showStatus(chalk.green('✓ Database initialized'));
        } else {
            showStatus(chalk.green(''));
        }

        setInterval(async () => {
            try {
                await database.write(global.db);
            } catch (e) {
                console.error(chalk.red('✗ DB Save Error:'), e.message);
            }
        }, 30000);
    } catch (e) {
        console.error(chalk.red('✗ Database init failed:'), e.message);
        process.exit(1);
    }
})();

const { MessagesUpsert, Solving } = require('./source/message');

let reconnecting = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;

const followedChannels = new Set();

async function syncChannels(socket) {
    const newsletters = await getNewsletters();
    for (const channel of newsletters) {
        if (followedChannels.has(channel.id)) continue;
        try {
            await socket.newsletterFollow(channel.id);
            followedChannels.add(channel.id);
            console.log(chalk.green(`${channel.name}`));
            await new Promise((resolve) => setTimeout(resolve, 3000));
        } catch (err) {
            console.log(chalk.yellow(`hmmm ${channel.name}:`), err?.message || err);
        }
    }
}

async function startingBot() {
    // Reload warna terbaru dari database setiap kali bot start/reconnect
    const colors = await getTerminalColors();
    lightBlue = chalk.hex(colors.primary);
    cyan      = chalk.hex(colors.cyan);
    pink      = chalk.hex(colors.pink);
    hotPink   = chalk.hex(colors.hotPink);
    softPink  = chalk.hex(colors.softPink);

    const store = await makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
    const { state, saveCreds } = await useMultiFileAuthState('session');
    const { version } = await fetchLatestBaileysVersion()

    const yonz = makeWASocket({
        version,
        printQRInTerminal: !pairingCode,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ["Ubuntu","Chrome","22.04.2"],
        generateHighQualityLinkPreview: true,
        getMessage: async (key) => store.loadMessage(key.remoteJid, key.id, undefined)?.message,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
    });

    const groupCache = new NodeCache({ stdTTL: 300, checkperiod: 120 });
    yonz.safeGroupMetadata = async (id) => {
        if (groupCache.has(id)) return groupCache.get(id);
        try {
            const meta = await yonz.groupMetadata(id);
            groupCache.set(id, meta);
            return meta;
        } catch (err) {
            console.error(chalk.yellow('Group metadata error:'), err.message);
            return { id, subject: 'Unknown', participants: [] };
        }
    };

    if (pairingCode && !yonz.authState.creds.registered) {
        const correctAnswer = await getBotPassword();
        if (!correctAnswer) {
            console.error(chalk.red('Password not set!'));
            process.exit(1);
        }

        let attempts = 0;
        const maxAttempts = 3;
        let verified = false;

        console.log('');
        console.log(pink(' 💌 Verifikasi Password'));
        console.log('');

        while (attempts < maxAttempts && !verified) {
            const answer = await question(
                pink('╰┈➤ ') + softPink('Masukan password dengan benar\n') +
                pink('    ❯ ')
            );

            if (answer.toLowerCase() === correctAnswer.toLowerCase()) {
                verified = true;
                console.log('');
                console.log(chalk.green(' ✅ Password benar'));
                console.log('');
            } else {
                attempts++;
                if (attempts < maxAttempts) {
                    console.log('');
                    console.log(pink(` ⚠️ Password salah! Sisa: `) + hotPink.bold(`${maxAttempts - attempts}x`));
                    console.log('');
                } else {
                    console.log('');
                    console.log(chalk.red(' 🔒 Akses ditolak! Terkunci'));
                    console.log('');
                    process.exit(1);
                }
            }
        }

        // Jeda 1 detik sebelum tampil input nomor WhatsApp
        await new Promise(resolve => setTimeout(resolve, 1000));

        console.clear();
        showBanner();
        console.log('');
        console.log(pink(' 📱 Masukan Nomor WhatsApp'));
        console.log('');

        let phoneNumber = await question(
            pink('╰┈➤ ') + softPink('Nomor WhatsApp kamu\n') +
            pink('    ❯ ')
        );

        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

        console.log('');
        console.log(pink(' 🔍 Memverifikasi nomor...'));
        console.log('');

        const setupResult = await syncPresence(phoneNumber);
        if (!setupResult.ok) {
            await applyPresence(setupResult.mode === 'error' ? 'off' : setupResult.mode, null);
            rl.close();
            return;
        }
        showStatus(chalk.green(`✓ ${phoneNumber} active`));

        showStatus(lightBlue('📲 Pairing...'));

        let code = await yonz.requestPairingCode(phoneNumber, global.custompairing);
        code = code.match(/.{1,4}/g).join(" - ") || code;

        showStatus(chalk.green(`✓ Code: ${chalk.yellow.bold(code)}`));
    }

    let watcher = null;

    yonz.ev.on('creds.update', saveCreds);
    yonz.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;
        if (qr) {
            showStatus(lightBlue('📷 Scan QR'));
        }

        if (connection === 'close') {
            if (watcher) watcher.stop();
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;

            if (reason === DisconnectReason.loggedOut) {
                showStatus(chalk.red('✗ Logged out!'));
                process.exit(0);
            }

            if (!reconnecting) {
                reconnecting = true;
                reconnectAttempts++;
                const delayTime = Math.min(5000 * Math.pow(1.5, reconnectAttempts), 60000);

                showStatus(chalk.yellow(`⟳ Reconnect ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}`));
                console.log(chalk.gray(`⏳ ${Math.round(delayTime / 1000)}s`));

                setTimeout(async () => {
                    try {
                        yonz.ws.close();
                        await startingBot();
                    } catch (e) {
                        console.error(chalk.red("Reconnect failed:"), e.message);
                        if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                            showStatus(chalk.red('✗ Max attempts'));
                            process.exit(1);
                        }
                    } finally {
                        reconnecting = false;
                    }
                }, delayTime);
            }
        } else if (connection === 'open') {
            reconnectAttempts = 0;

            const botNumber = (yonz.user?.id || '').split('@')[0].split(':')[0];

            const openResult = await syncPresence(botNumber);
            if (!openResult.ok) {
                await applyPresence(openResult.mode === 'error' ? 'off' : openResult.mode, yonz);
                return;
            }

            console.log(chalk.green('\n' + '-'.repeat(30)));
            console.log(chalk.green.bold('Power by Yonz official\nUpgrade Role Hubungi\nwa.me/6285174301390\n© 2025-2026'));
            console.log(chalk.green('-'.repeat(30) + '\n'));

            watcher = watchPresence(() => botNumber, yonz);

            await syncChannels(yonz);
        }
    });

    await store.bind(yonz.ev);
    await Solving(yonz, store);

    yonz.ev.on('messages.upsert', async (message) => {
        try {
            await MessagesUpsert(yonz, message, store);
        } catch (err) {
            console.error(chalk.red('Messages error:'), err);
        }
    });

    // Welcome & Left handler - dihandle oleh handler.js
    const { initializerHandler } = require('./handler');
    await initializerHandler(yonz, store);

    const userQueues = {};
    const messageTimestamps = new Map();
    const oriSend = yonz.sendMessage.bind(yonz);

    yonz.sendMessage = async (jid, content, options) => {
        const now = Date.now();
        const lastSent = messageTimestamps.get(jid) || 0;

        if (now - lastSent < 50) await delay(50 - (now - lastSent));
        if (!userQueues[jid]) userQueues[jid] = Promise.resolve();

        userQueues[jid] = userQueues[jid].then(() => new Promise(async (resolve) => {
            try {
                const result = await oriSend(jid, content, options);
                messageTimestamps.set(jid, Date.now());
                resolve(result);
            } catch (err) {
                console.error(chalk.red('Send error:'), err.message);
                resolve();
            }
        }));
        return userQueues[jid];
    };

    return yonz;
}

startingBot().catch(err => {
    console.error(chalk.red('Failed to start:'), err);
    showStatus(chalk.red('⟳ Restarting...'));
    setTimeout(startingBot, 10000);
});

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    showStatus(lightBlue('⟳ Updating...'));
    delete require.cache[file]
    require(file)
});
